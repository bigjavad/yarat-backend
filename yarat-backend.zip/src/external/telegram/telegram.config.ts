export const telegramConfig = {
    chat_id: '-1002685290474',
    token: '7509996020:AAF66Re3s2UoYUTW_7jC3YLJi4E2UEa42Po',
    url: 'https://api.mizbanfa.net/bot',
};
