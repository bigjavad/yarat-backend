export const smsConfig = {
    url: 'https://console.melipayamak.com/api/send/simple/7577186d786b4911bee63390c0f3c5f9',
};
