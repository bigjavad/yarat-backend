export const UploadPathConst =
    {
        USER: 'user',
        POST: 'post',
        POST_CONTENT: 'post-content',
        CATEGORY_MENU: 'category-menu',
        CAR_BODY_COLOR: 'car-body-color',
        CAR: 'car',
        PROVINCE: 'province',
        GALLERY: 'gallery',
    };
