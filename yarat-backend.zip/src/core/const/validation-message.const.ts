export const VALIDATION_MESSAGE_CONST = {
    STRING_FORMAT: 'فرمت var باید به صورت رشته باشد',
    IS_REQUIRED: 'فیلد var اجباری می باشد.',
    CAR_ID_IS_REQUIRED:'شناسه خودرو اجباری می باشد',


}
