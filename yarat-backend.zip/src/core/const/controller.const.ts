export const CONTROLLER_CONST = {
    AUTH:'auth',
    CATEGORY_MENU:'category-menu',
    CITY:'city',
    GALLERY: 'gallery',
    CAR_BODY_COLOR:'car-body-color',
    CAR: 'car',
    LOGGER:'logger',
    POST_COMMENT:'post-comment',
    POST:'post',
    PROPERTY_VALUE:'property-value',
    PROPERTY:'property',
    PROVINCE:'province',
    SENTENCE:'sentence',
    USER:'user',
    BASE_VAR:'var-base',
    UPLOAD:'upload',
    ORDERS: 'orders'
}
