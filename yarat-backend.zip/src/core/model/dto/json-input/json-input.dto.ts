export class JsonInputDto {
    fieldId: number;
    hashCode: string;
    price:number;
}
