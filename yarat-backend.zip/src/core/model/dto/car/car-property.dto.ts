import {BaseEntityModel} from "../../../entity/base-entity-model";
export class CarPropertyDto extends BaseEntityModel {
    content:string;
    title:string;
}
