export class UserOtpDto {
    phoneNumber:string;
    code:string;
}
