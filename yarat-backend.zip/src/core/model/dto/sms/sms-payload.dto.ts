
export class SmsPayloadDto {
    to: string;
    text: string;
}
