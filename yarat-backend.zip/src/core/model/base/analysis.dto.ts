export class AnalysisDto{
    count:number;
    date:Date;
}
