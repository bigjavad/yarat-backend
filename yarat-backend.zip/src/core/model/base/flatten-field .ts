
export class FlattenField {
    path: string;
    alias: string;
}
