export class ImageSizeDto {
    xl: string;
    md: string;
    sm: string;
    xs: string;
}
