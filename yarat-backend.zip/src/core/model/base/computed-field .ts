export class ComputedField {
    name: string;
    expression: string;
}
