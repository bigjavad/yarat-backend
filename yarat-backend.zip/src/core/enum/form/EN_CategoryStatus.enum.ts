export enum EN_CategoryStatusEnum {
    CATEGORY_STATUS_ACTIVE="categoryStatusActive",
    CATEGORY_STATUS_DISABLED="categoryStatusDisabled"
}
