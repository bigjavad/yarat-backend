export enum EN_CarStatusEnum {
    CAR_STATUS_EXISTING="carStatusExisting",
    CAR_STATUS_NON_EXISTENT= "carStatusNonExistent"
}
