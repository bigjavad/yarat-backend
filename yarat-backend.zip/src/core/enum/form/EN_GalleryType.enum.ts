export enum EN_GalleryTypeEnum {
    IMAGE = "image",
    VIDEO = "video"
}
