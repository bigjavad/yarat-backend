export enum EN_PostStatusEnum {
    POST_STATUS_ACTIVE="postStatusActive",
    POST_STATUS_DISABLED="postStatusDisabled",
    POST_STATUS_DRAFT ="postStatusDraft"
}
