export enum EN_CarCategoryEnum {
    TWO_PEOPLE= "twoPeople",
    FOUR_PEOPLE= "fourPeople",
    EIGHT_PEOPLE= "eightPeople",
    TWELVE_PEOPLE="twelvePeople"
}
