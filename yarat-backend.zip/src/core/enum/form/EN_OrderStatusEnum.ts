export enum EN_OrderStatusEnum {
    ORDER_STATUS_UNDER_REVIEW = "orderStatusUnderReview",
    ORDER_STATUS_COMPLETED = "orderStatusCompleted",
    ORDER_STATUS_CANCELED = "orderStatusCanceled"
}
