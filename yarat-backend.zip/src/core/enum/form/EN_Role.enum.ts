export enum EN_RoleEnum{
    USER="user",
    ADMIN="admin"
}
