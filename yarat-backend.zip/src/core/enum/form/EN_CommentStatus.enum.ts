export enum EN_CommentStatusEnum {
    ENABLE = "enable",
    DISABLED = "disabled",
    UNDER_REVIEW = "underReview",
    SPAM = "spam"
}
