export enum EN_ExceptionStatus {
    BAD_REQUEST=400,
    NOT_FOUND=404
}
