
export enum EN_TargetActionEnum {
    SAVE="save",
    UPDATE="update"
}
